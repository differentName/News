//
//  ViewController.m
//  cutelogin
//
//  Created by nb616 on 16/1/9.
//  Copyright © 2016年 国服第一. All rights reserved.
//

#import "ViewController.h"
#import "CateAnimationLogin.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CateAnimationLogin *login=[[CateAnimationLogin alloc]initWithFrame:CGRectMake(0, -20,self.view.bounds.size.width, 400)];
    self.view.backgroundColor = [UIColor cyanColor];
    [self.view addSubview:login];
  
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
